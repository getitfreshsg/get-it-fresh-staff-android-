package com.wetmarket.staff.Util;

public interface OnItemClickListener {
    void onItemClick(int position, int which, Object object);
}
